package com.Haritha;

public class ThreadCounter8_1 {

	public static void main(String args[])

	{

	Counter counter = new Counter(25);

	counter.run();

	}
}


